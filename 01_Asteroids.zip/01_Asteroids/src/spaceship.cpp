#include "spaceship.h"
#include "physicsobject.h"
using namespace std;

Spaceship::Spaceship(raylib::Vector2 initialPos)
: PhysicsObject(initialPos, texturePath_, 1.0, 0.0)
, health_(maxHealth_)
{
    speed_=0;
}

void Spaceship::update()
{
    if(IsKeyDown(KEY_W))
        accelerate(raylib::Vector2{0.f, -600}.Rotate(DEG2RAD * rotationSpeed_));
    if(IsKeyDown(KEY_A))
        rotate(-rotationSpeed_);
    if(IsKeyDown(KEY_D))
        rotate(rotationSpeed_);

    PhysicsObject::update();
}

int Spaceship::getHealth() const
{
    return health_;
}




/*void Spaceship::handleCollision(std::shared_ptr<GameObject> other) {
    std::shared_ptr<Asteroid> asteroid = std::dynamic_pointer_cast<Asteroid>(other);

    if(asteroid != nullptr){
        health_ = health_ -5;
        asteroid->markForDeletion();
    }
}*/

