#include "physicsobject.h"
#include <iostream>
using namespace std;


PhysicsObject::PhysicsObject(raylib::Vector2 initialPos, string texturePath, float initialScale, float initialRot)
        : GameObject(initialPos, texturePath, initialScale, initialRot)
        ,speed_(5)
        {

}

void PhysicsObject::update() {
    pos_ +=speed_;
    float dt = 1/60;
    speed_ = speed_ + acc_ * dt;
    speed_ = speed_ - speed_ * friction;
    move(speed_);
    acc_ = 0;
}

void PhysicsObject::accelerate(raylib::Vector2 acc){
    acc_ = acc;
}


void PhysicsObject::setSpeed(raylib::Vector2 speed){
    speed_= speed;
};